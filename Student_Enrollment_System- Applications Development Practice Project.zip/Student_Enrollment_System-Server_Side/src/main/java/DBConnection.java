
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
    
    public static Connection derbyConnection() throws SQLException{
        
        String DATABASE_URL = "jdbc:derby://localhost:1527/StudentEnrollment";
        String USERNAME = "administrator";
        String PASSWORD = "admin";
        
        Connection connect = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
        return connect;
    }
}
