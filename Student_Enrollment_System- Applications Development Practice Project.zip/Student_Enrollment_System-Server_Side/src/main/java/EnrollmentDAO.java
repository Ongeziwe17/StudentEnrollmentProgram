import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * @author Ongeziwe Mtolo
 * Thapelo Ngwenya
 * Silindokuhle Semane
 */

public class EnrollmentDAO {
    private Connection con;
    
    public EnrollmentDAO() throws SQLException{
        this.con = DBConnection.derbyConnection();
    }
    
    //admin login authentication operation
    public boolean authenticateAdmin(String adminId, String password) throws SQLException {
        String adminLoginQuery = "SELECT * FROM ADMIN WHERE ADMIN_ID = ? AND PASSWORD = ?";
        try (PreparedStatement statement = con.prepareStatement(adminLoginQuery)) {
            statement.setString(1, adminId);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next(); // If a row with inserted data is found, authentication is successful
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    //student login authentication operation
    public boolean authenticateStudent(String studentId, String password) throws SQLException {
        String studentLoginQuery = "SELECT * FROM STUDENT WHERE STUDENT_ID = ? AND PASSWORD = ?";
        try(PreparedStatement statement = con.prepareStatement(studentLoginQuery)) {
            statement.setString(1, studentId);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next(); // If a row with inserted data is found, authentcation is successful
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    //Save student dao operation
    public Student saveStudent(Student student) throws SQLException {
        int ok;
        String registerStudentQuery = "INSERT INTO STUDENT(TITLE, STUDENT_ID, FIRST_NAME, LAST_NAME, GENDER, HOME_LANGUAGE, EMAIL_ADDRESS, PASSWORD, CELLPHONE_NUMBER, ABOUT_US) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = con.prepareStatement(registerStudentQuery)) {
            statement.setString(1, student.getTitle());
            statement.setString(2, student.getStudentId());
            statement.setString(3, student.getFirstName());
            statement.setString(4, student.getLastName());
            statement.setString(5, student.getGender());
            statement.setString(6, student.getHomeLanguage());
            statement.setString(7, student.getEmailAddress());
            statement.setString(8, student.getPassword());
            statement.setString(9, student.getCellphoneNumber());
            statement.setString(10, student.getAboutUs());
            ok = statement.executeUpdate();
            if (ok > 0) {
                return student;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //Save course dao operation
    public Course saveCourse(Course course) throws SQLException {
        int ok;
        String addCourseQuery = "INSERT INTO COURSES(SUBJECT_ID, SUBJECT_CODE, SUBJECT_NAME, FACULTY, DESCRIPTION) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = con.prepareStatement(addCourseQuery)) {
            statement.setString(1, course.getSubjectId());
            statement.setString(2, course.getSubjectCode());
            statement.setString(3, course.getSubjectName());
            statement.setString(4, course.getFaculty());
            statement.setString(5, course.getDescription());
            ok = statement.executeUpdate();
            if (ok > 0) {
                return course;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //retrieve operations for student and course
    public List<Student> retrieveStudent() throws SQLException {
        List<Student> studentList = new ArrayList<>();
        String retrieveStudentsQuery = "SELECT * FROM STUDENT";
    
        try (PreparedStatement statement = this.con.prepareStatement(retrieveStudentsQuery);
            ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                String title = resultSet.getString("TITLE");
                String studentId = resultSet.getString("STUDENT_ID");
                String firstName = resultSet.getString("FIRST_NAME");
                String lastName = resultSet.getString("LAST_NAME");
                String gender = resultSet.getString("GENDER");
                String homeLanguage = resultSet.getString("HOME_LANGUAGE");
                String emailAddress = resultSet.getString("EMAIL_ADDRESS");
                String password = resultSet.getString("PASSWORD");
                String cellphoneNumber = resultSet.getString("CELLPHONE_NUMBER");
                String aboutUs = resultSet.getString("ABOUT_US");

                studentList.add(new Student(title, studentId, firstName, lastName, gender, homeLanguage, emailAddress, password, cellphoneNumber, aboutUs));
            }
        }
        return studentList;
    }
    
    public List<Course> retrieveCourse() throws SQLException{
        List<Course> courseList = new ArrayList<>();
        String retrieveCoursesQuery = "SELECT * FROM COURSES";
        
        try (PreparedStatement statement = this.con.prepareStatement(retrieveCoursesQuery);
            ResultSet resultSet = statement.executeQuery()){
            while(resultSet.next()){
                String subjectId = resultSet.getString("SUBJECT_ID");
                String subjectCode = resultSet.getString("SUBJECT_CODE");
                String subjectName = resultSet.getString("SUBJECT_NAME");
                String faculty = resultSet.getString("FACULTY");
                String description = resultSet.getString("DESCRIPTION");
                
                courseList.add(new Course(subjectId, subjectCode, subjectName, faculty, description));
            }
        }
        return courseList;
    }
    
    public List<Student> searchStudent(String searchTerm) throws SQLException {
        List<Student> studentList = new ArrayList<>();
        String searchStudentQuery = "SELECT * FROM STUDENT WHERE STUDENT_ID = ? OR FIRST_NAME = ? OR LAST_NAME = ?";
    
        try (PreparedStatement statement = con.prepareStatement(searchStudentQuery)) {
            statement.setString(1, searchTerm);
            statement.setString(2, searchTerm);
            statement.setString(3, searchTerm);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String title = resultSet.getString("TITLE");
                    String studentId = resultSet.getString("STUDENT_ID");
                    String firstName = resultSet.getString("FIRST_NAME");
                    String lastName = resultSet.getString("LAST_NAME");
                    String gender = resultSet.getString("GENDER");
                    String homeLanguage = resultSet.getString("HOME_LANGUAGE");
                    String emailAddress = resultSet.getString("EMAIL_ADDRESS");
                    String password = resultSet.getString("PASSWORD");
                    String cellphoneNumber = resultSet.getString("CELLPHONE_NUMBER");
                    String aboutUs = resultSet.getString("ABOUT_US");

                    studentList.add(new Student(title, studentId, firstName, lastName, gender, homeLanguage, emailAddress, password, cellphoneNumber, aboutUs));
                }
            }
        } 
        return studentList;
    }

    
    public List<Course> searchCourse(String faculty) throws SQLException{
        String searchFacultyQuery = "SELECT * FROM COURSES WHERE FACULTY = ?";
        try(PreparedStatement statement = con.prepareStatement(searchFacultyQuery)){
            if("All".equalsIgnoreCase(faculty)){
                return retrieveCourse();
            } else {
                statement.setString(1, faculty);
                try (ResultSet resultSet = statement.executeQuery()){
                    List<Course> courseList = new ArrayList<>();
                    while (resultSet.next()){
                        String subjectId = resultSet.getString("SUBJECT_ID");
                        String subjectCode = resultSet.getString("SUBJECT_CODE");
                        String subjectName = resultSet.getString("SUBJECT_NAME");
                        String faculties = resultSet.getString("FACULTY");
                        String description = resultSet.getString("DESCRIPTION");
                        
                        courseList.add(new Course(subjectId, subjectCode, subjectName, faculties, description));
                    }
                    return courseList;
                }
            }
        }
    }
    
    // DELETE operations for course and student
    public boolean deleteCourse(String subjectId) {
        boolean subjectEnrolledDeleted = deleteCourseEnrolled(subjectId);
        //check if subje is in enrollment, if so delete subject
        if(subjectEnrolledDeleted || !deleteCourseEnrolled(subjectId)){
        //Either subject in enrollements was deleted or the subject is nto enrolled, proceed to delete subject
            String deleteSubjectQuery = "DELETE FROM COURSES WHERE SUBJECT_ID = ?";
            try(PreparedStatement statement = con.prepareStatement(deleteSubjectQuery)){
                statement.setString(1, subjectId);
                int rowsDeleted = statement.executeUpdate();
                return rowsDeleted > 0;
            } catch (SQLException ex) {
                ex.printStackTrace();
                return false;
            }
        }
        return false;
    }    
    
    private boolean deleteCourseEnrolled(String subjectId){
        String deleteCourseEnrolledQuery = "DELETE FROM ENROLLMENTS WHERE SUBJECT_ID = ?";
        try(PreparedStatement statement = con.prepareStatement(deleteCourseEnrolledQuery)){
            statement.setString(1, subjectId);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteStudent(String studentId){
        boolean studentEnrollmentDeleted = deleteStudentEnrolled(studentId);
        //check if student is enrolled, if so delete student enrollment  
        if(studentEnrollmentDeleted || !deleteStudentEnrolled(studentId)){
            // Either student enrollments were deleted or the student is not enrolled, proceed to delete student
            String deleteStudentQuery = "DELETE FROM STUDENT WHERE STUDENT_ID = ?";
            try(PreparedStatement statement = con.prepareStatement(deleteStudentQuery)){
                statement.setString(1, studentId);
                int rowsDeleted = statement.executeUpdate();
                return rowsDeleted > 0;
            } catch (SQLException ex) {
                ex.printStackTrace();
                return false;
            }
        }
        return false;
    }
    
    private boolean deleteStudentEnrolled(String studentId){
        String deleteStudentEnrollmentQuery = "DELETE FROM ENROLLMENTS WHERE STUDENT_ID = ?";
        try(PreparedStatement statement = con.prepareStatement(deleteStudentEnrollmentQuery)){
            statement.setString(1, studentId);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
   
    
    //enrollment operation for student
    public boolean enrollStudent(String subjectId, String studentId){
        // Check if the enrollment is not a duplicate
        if(!duplicateEnrollment(subjectId, studentId)){
            // If it's not a duplicate, insert the enrollment into the 'enrollments' table
            String enrollStudentQuery = "INSERT INTO ENROLLMENTS(SUBJECT_ID, STUDENT_ID) VALUES (?, ?)";
            try(PreparedStatement statement = con.prepareStatement(enrollStudentQuery)){
                statement.setString(1, subjectId);
                statement.setString(2, studentId);
                int rowsAffected = statement.executeUpdate();
                return rowsAffected > 0; // Return true if enrollment was successful
            } catch (SQLException ex) {
            }
        }
        return false;
    }
    
    private boolean duplicateEnrollment(String subjectId, String studentId) {
        String checkDuplicateEnrollmentQuery = "SELECT * FROM ENROLLMENTS WHERE SUBJECT_ID = ? AND STUDENT_ID = ?";
        try(PreparedStatement statement = con.prepareStatement(checkDuplicateEnrollmentQuery)){
            statement.setString(1, subjectId);
            statement.setString(2, studentId);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public List<Enrollment> retrieveEnrollments() {
        List<Enrollment> enrolledList = new ArrayList<>();
        String retrieveEnrollmentsQuery = "SELECT * FROM ENROLLMENTS";
        try(PreparedStatement statement = con.prepareStatement(retrieveEnrollmentsQuery)){
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int enrollmentId = resultSet.getInt("ENROLLMENT_ID");
                String subjectId = resultSet.getString("SUBJECT_ID");
                String studentId = resultSet.getString("STUDENT_ID");
                
                enrolledList.add(new Enrollment(enrollmentId, subjectId, studentId));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return enrolledList;
    }    
    
    public List<Enrollment> retrieveSpecificEnrollments(String searchTerm) throws SQLException{
        List<Enrollment> enrollList = new ArrayList<>();
        String retrieveEnrollmentList = "SELECT * FROM ENROLLMENTS WHERE SUBJECT_ID = ? OR STUDENT_ID = ?";
        try(PreparedStatement statement = con.prepareStatement(retrieveEnrollmentList)){
            statement.setString(1, searchTerm);
            statement.setString(2, searchTerm);
            
            try (ResultSet resultSet = statement.executeQuery()){
                while(resultSet.next()){
                    int enrollmentId = resultSet.getInt("ENROLLMENT_ID");
                    String subjectId = resultSet.getString("SUBJECT_ID");
                    String studentId = resultSet.getString("STUDENT_ID");
                    
                    enrollList.add(new Enrollment(enrollmentId, subjectId, studentId));
                }
            }
        }
        return enrollList;
    }
    
    public boolean cancelEnrollment(String subjectId){
        String cancelEnrollmentQuery = "DELETE FROM ENROLLMENTS WHERE SUBJECT_ID = ?";
        try(PreparedStatement statement = con.prepareStatement(cancelEnrollmentQuery)){
            statement.setString(1, subjectId);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}