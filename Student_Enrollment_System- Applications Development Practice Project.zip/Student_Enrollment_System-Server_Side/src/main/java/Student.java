
import java.io.Serializable;


public class Student implements Serializable{
    
    private String title;
    private String studentId;
    private String firstName;
    private String lastName;
    private String gender;
    private String homeLanguage;
    private String emailAddress;
    private String password;
    private String cellphoneNumber;
    private String aboutUs;

    public Student() {
    }

    public Student(String title, String studentId, String firstName, String lastName, String gender, String homeLanguage, String emailAddress, String password, String cellphoneNumber, String aboutUs) {
        this.title = title;
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.homeLanguage = homeLanguage;
        this.emailAddress = emailAddress;
        this.password = password;
        this.cellphoneNumber = cellphoneNumber;
        this.aboutUs = aboutUs;
       
    }
    
    public Student(String studentId, String password) {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHomeLanguage() {
        return homeLanguage;
    }

    public void setHomeLanguage(String homeLanguage) {
        this.homeLanguage = homeLanguage;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCellphoneNumber() {
        return cellphoneNumber;
    }

    public void setCellphoneNumber(String cellphoneNumber) {
        this.cellphoneNumber = cellphoneNumber;
    }

    public String getAboutUs() {
        return aboutUs;
    }

    public void setAboutUs(String aboutUs) {
        this.aboutUs = aboutUs;
    }

    @Override
    public String toString() {
        return "Student{" + "title=" + title + ", studentId=" + studentId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", homeLanguage=" + homeLanguage + ", emailAddress=" + emailAddress + ", password=" + password + ", cellphoneNumber=" + cellphoneNumber + ", aboutUs=" + aboutUs + '}';
    }
}