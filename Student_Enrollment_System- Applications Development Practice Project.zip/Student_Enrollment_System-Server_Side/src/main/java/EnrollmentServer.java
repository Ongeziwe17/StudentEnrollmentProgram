
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
 


/*
 * @author Ongeziwe Mtolo
 * Thapelo Ngwenya
 * Silindokuhle Semane
 */

public class EnrollmentServer {
    
    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static ServerSocket serverSocket;
    private static Socket clientSocket;
    private static Object receivedObject;
    private EnrollmentDAO dao;
    
    public EnrollmentServer() throws IOException, SQLException, ClassNotFoundException, ParseException{
       
        serverSocket = new ServerSocket(8001, 10);
        dao = new EnrollmentDAO();
        
        System.out.println("Waiting for client connection to: " + serverSocket.getInetAddress().getHostName());
        clientSocket = serverSocket.accept();
        System.out.println("Client has connected to: " + serverSocket.getInetAddress().getHostName() + " Port: " + serverSocket.getLocalPort());
        
        getStreams();
        processClientRequests();
        closeConnection();
    }
    
    private void getStreams() throws IOException{
        
        out = new ObjectOutputStream(clientSocket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(clientSocket.getInputStream());    
    }
    
    private void processClientRequests() throws IOException, ClassNotFoundException, SQLException {
        
        while(true){
            receivedObject = in.readObject();
            
            if (receivedObject instanceof String) {
                String request = (String) receivedObject;
                
                if (request.equals("Exit")) {
                    // Handle client exit request
                    break; // Exit the loop and close the connection
                } 
                
                else if (request.equals("AuthenticateAdmin")){
                    String adminId = (String) in.readObject();
                    String password = (String) in.readObject();
                    boolean isAuthenticated = dao.authenticateAdmin(adminId, password);
                    System.out.println("ADMIN LOGIN SUCCESSFULLY");
                    out.writeObject(isAuthenticated);
                    out.flush();
                }
                
                else if (request.equals("RegisterStudent")) {
                    // Handle student registration
                    Student student = (Student) in.readObject();
                    Student savedStudent = dao.saveStudent(student);
                    System.out.println("STUDENT REGISTERED SUCCESSFULLY");
                    out.writeObject(savedStudent);
                    out.flush();
                } 
                
                else if (request.equals("AddCourse")){
                    Course course = (Course) in.readObject();
                    Course savedCourse = dao.saveCourse(course);
                    System.out.println("SUBJECT ADDED SUCCESSFULLY");
                    out.writeObject(savedCourse);
                    out.flush();
                }
                
                else if (request.equals("AuthenticateStudent")) {
                    // Handle student authentication
                    //Student studentLogin = (Student) in.readObject();
                    String studentId = (String) in.readObject();
                    String password = (String) in.readObject();
                    boolean isAuthenticated = dao.authenticateStudent(studentId, password);
                    System.out.println("STUDENT LOGIN SUCCESSFUL");
                    out.writeObject(isAuthenticated);
                    out.flush();
                } 
                
                else if (request.equals("Students")) {
                    // Handle the request to retrieve students
                    List<Student> studentList = dao.retrieveStudent(); // Call the DAO method to retrieve students
                    out.writeObject(studentList); // Send the list of students to the client
                    out.flush();
                    System.out.println("Student data sent to the client.");
                } 
                
                else if (request.equals("findStudent")){
                    String searchTerm = (String) in.readObject();
                    List<Student> studentList = dao.searchStudent(searchTerm);
                    out.writeObject(studentList);
                    out.flush();
                    System.out.println("Searched student(s) sent to the client");
                }
                
                else if (request.equals("Subjects")){
                    //Handle the request to retrieve subjects from the database
                    List<Course> courseList = dao.retrieveCourse();// call the dao method to retrieve courses
                    out.writeObject(courseList);//send the list to the client
                    out.flush();
                    System.out.println("Courses sent to the client");
                } 
                
                else if(request.equals("RetrieveSubjectsByFaculty")){
                    // Handle the request to retrieve subjects by faculty
                    String selectedFaculty = (String) in.readObject();
                    List<Course> courseList;
                    if ("All:".equals(selectedFaculty)){
                        //if all is selected return all subjects
                        courseList = dao.retrieveCourse();
                        out.writeObject(courseList);
                        out.flush();
                    } else if("Accounting Stream".equals(selectedFaculty) || "Science Stream".equals(selectedFaculty) || "Art/Humanities Stream".equals(selectedFaculty)){
                        courseList = dao.searchCourse(selectedFaculty);
                        out.writeObject(courseList);
                        out.flush();
                    }
                    System.out.println("Subjects data sent to the client based on selected faculty: " + selectedFaculty);
                } 
                
                else if (request.equals("DeleteSubject")) {
                    // Handle the request to delete a course
                    String subjectId = (String) in.readObject();
                    boolean isDeleted = dao.deleteCourse(subjectId); // Call the DAO method to delete the course
                    if (isDeleted) {
                        out.writeObject("CourseDeleted");
                    } else {
                        out.writeObject("CourseDeletionFailed");
                    }
                    out.flush();
                } 
                
                else if (request.equals("DeregisterStudent")){
                    //handle request to delete student
                    String studentId = (String) in.readObject();
                    boolean isDeregistered = dao.deleteStudent(studentId);
                    if(isDeregistered){
                        out.writeObject("StudentDeregistered");
                    } else {
                        out.writeObject("StudentDeregistrationFailed");
                    }
                    out.flush();
                } 
                
                else if (request.equals("Enroll")){
                    // Handle the enrollment request
                    String studentId = (String) in.readObject();
                    String subjectId = (String) in.readObject();
                    boolean isEnrolled = dao.enrollStudent(subjectId, studentId);
                    if(isEnrolled){
                        out.writeObject("Enrollment successful");
                    } else {
                        out.writeObject("EnrollmentUnsuccessful");
                    }
                    out.flush();
                } 
                
                else if (request.equals("Enrollments")){
                    List<Enrollment> enrolledList = dao.retrieveEnrollments();
                    out.writeObject(enrolledList);//send the list to the client
                    out.flush();
                    System.out.println("EnrolledList sent to the client");
                } 
                
                else if (request.equals("findSpecificEnrollments")){
                    String searchTerm = (String) in.readObject();
                    List<Enrollment> enrollList = dao.retrieveSpecificEnrollments(searchTerm);
                    out.writeObject(enrollList);
                    out.flush();
                }
                
                else if(request.equals("CancelEnrollment")){
                    String subjectId = (String) in.readObject();
                    boolean isCancelled = dao.cancelEnrollment(subjectId);
                    if(isCancelled){
                        out.writeObject("EnrollmentCancelled");
                    } else {
                        out.writeObject("EnrollmentNotCancelled");
                    }
                }
            } 
        }
    }
    
    private void closeConnection() throws IOException{
        
        out.writeObject("Exit");
        out.close();
        out.flush();
        in.close();
        clientSocket.close();
        serverSocket.close();
        System.out.println("\nServer is closing all connections : ");
    }
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     * @throws java.text.ParseException
     */
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException, ParseException {
        new EnrollmentServer();
    }
}
