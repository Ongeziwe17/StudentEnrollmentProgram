
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/*
 * @author Ongeziwe Mtolo
 * Thapelo Ngwenya
 * Silindokuhle Semane
 */
public class EnrollmentClient {
    
    private  ObjectInputStream in;
    private  ObjectOutputStream out;
    private Socket socket;
    private JFrame frame;
    private JLabel idLabel, passwordLabel;
    private JTextField idField, passwordField;
    private JPanel panel1, panel2;
    private JLabel label8;
    private JButton adminButton, studentButton, exitButton;
    
    public EnrollmentClient() throws UnknownHostException, IOException{
        
        System.out.println("Attempting connection to the server: ");
        socket = new Socket(InetAddress.getLocalHost(), 8001);
        System.out.println("Client id connected to server: " + socket.getInetAddress().getHostName() + " Port: " + socket.getPort());
        
        out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(socket.getInputStream());
        
    }
    
    private void createGUI(){
        
        frame = new JFrame();        
        
        label8 = new JLabel("ACADEMY ENROLLMENT");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
        idLabel = new JLabel("ID: ");
        idLabel.setBounds(130, 200, 100, 25);
        idField = new JTextField();
        idField.setBounds(150, 200, 195, 25);
        
        passwordLabel = new JLabel("Password: ");
        passwordLabel.setBounds(88, 235, 100, 25);
        passwordField = new JTextField();
        passwordField.setBounds(150, 235, 195, 25);
                
        
        adminButton = new JButton("ADMIN");
        adminButton.setBounds(150,270,97,20);
        adminButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //Admin login function(authentication)
                String adminId = idField.getText();
                String password = passwordField.getText();
                //checking if fields are not empty
                if(adminId.isEmpty() || password.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "Both fields must be filled.");
                } else {
                    try {
                        //sending request to the server
                        out.writeObject("AuthenticateAdmin");
                        out.writeObject(adminId);
                        out.writeObject(password);
                        out.flush();
                        //response from the server
                        boolean isAuthenticated = (boolean) in.readObject();
                        if(isAuthenticated){
                            //if student exist in database send a success message
                            System.out.println("Admin LOGGED IN SUCCESSFULLY");
                            JOptionPane.showMessageDialog(frame, "Admin logged in successfully.");
                            //clear fields
                            idField.setText("");
                            passwordField.setText("");
                            //dispose the existing gui and display following gui
                            frame.dispose();
                            adminOptionsGUI();
                        } else {
                            //if student does not exits send an unsuccessful message
                            System.out.println("Admin LOGIN FAILED");
                            JOptionPane.showMessageDialog(frame, "Admin login failed. Please check your credentials.");
                        }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        studentButton = new JButton("STUDENT");
        studentButton.setBounds(250,270, 97,20);
        studentButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //student login function(Authentication)
                String studentId = idField.getText();
                String password = passwordField.getText();
                
                //Checking if all field are filled
                if(studentId.isEmpty() || password.isEmpty()){
                    //Error message if one of the fields are not filled
                    JOptionPane.showMessageDialog(frame, "Both fields must be filled.");
                } else {
                    try {
                        //sending request to the server to authenticate student
                        out.writeObject("AuthenticateStudent");
                        out.writeObject(studentId);
                        out.writeObject(password);
                        out.flush();
                        //recieves response from server that student is authenticated
                        boolean isAuthenticated = (boolean) in.readObject();
                        if(isAuthenticated){
                            //if student exist in database send a success message
                            System.out.println("STUDENT LOGGED IN SUCCESSFULLY");
                            JOptionPane.showMessageDialog(frame, "Student logged in successfully.");
                            //clear fields
                            idField.setText("");
                            passwordField.setText("");
                            //dispose the existing gui and display following gui
                            frame.dispose();
                            retrieveSubjectsForStudentGui();
                        } else {
                            //if student does not exits send an unsuccessful message
                            System.out.println("STUDENT LOGIN FAILED");
                            JOptionPane.showMessageDialog(frame, "Student login failed. Please check your credentials.");
                        }
                    } catch (IOException |ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        
        exitButton = new JButton("EXIT");
        exitButton.setBounds(1,440,485,20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    //exit program function
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,500,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);
        
        frame.add(idLabel);
        frame.add(idField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(adminButton);
        frame.add(studentButton);
        frame.add(exitButton);
        frame.add(panel2);
        frame.add(panel1, BorderLayout.CENTER);
        
        frame.setTitle("ACADEMY ENROLLMENT");
        frame.setSize(500, 500);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
    private void studentSIGNUP(){
        
        JFrame studentSignUpFrame;
        JPanel panel1, panel2;
        JLabel titleLabel, studentIdLabel, firstNameLabel, lastNameLabel, genderLabel, homeLanguageLabel, emailAddressLabel, passwordLabel, cellphoneNumberLabel, whereDidYouHearAboutUsLabel, label8;
        JComboBox titleComboBox, genderComboBox, homeLanguageComboBox, whereDidYouHearAboutUsComboBox;
        JTextField studentIdField, firstNameField, lastNameField, emailAddressField, passwordField, cellphoneNumberField;
        JButton signUpStudentButton, exitButton, returnButton;
        
        
        studentSignUpFrame = new JFrame();
        //title components
        titleLabel = new JLabel("Title: ");
        titleLabel.setBounds(217, 50, 100, 20);
        
        String title[] = {"Choose:", "MR", "MRS", "MISS", "DR", "ADV", "JUDGE"};
        titleComboBox = new JComboBox(title);
        titleComboBox.setBounds(250, 50, 150, 25);
        
        //student id components
        studentIdLabel = new JLabel("Student ID: "); 
        studentIdLabel.setBounds(180, 80, 100, 20); 
        
        studentIdField = new JTextField();
        studentIdField.setBounds(250, 80, 150, 25);
        
        //first name components
        firstNameLabel = new JLabel("First Name: "); 
        firstNameLabel.setBounds(180, 110, 100, 20);
        
        firstNameField = new JTextField();
        firstNameField.setBounds(250, 110, 150, 25);
        
        //last name components
        lastNameLabel = new JLabel("Last Name: "); 
        lastNameLabel.setBounds(180, 140, 100, 20);
        
        lastNameField = new JTextField();
        lastNameField.setBounds(250, 140, 150, 25);
        
        //gender components
        genderLabel =  new JLabel("Gender: ");
        genderLabel.setBounds(196, 170, 100, 20);
        
        String Gender[]={"Choose:","Male", "Female", "Other"};        
        genderComboBox = new JComboBox(Gender);    
        genderComboBox.setBounds(250, 170, 150, 25);
        
        
        //home language components
        homeLanguageLabel = new JLabel("Home Language: ");
        homeLanguageLabel.setBounds(149, 200, 200, 20);
        
        String homeLanguage[] = {"Choose:", "English", "IsiXhosa", "IsiZulu", "Afrikaans", "Sesotho", "Sepedi", "TshiVenda", "Setswana", "Seswati", "Ndebele", "Xitsonga"};
        homeLanguageComboBox = new JComboBox(homeLanguage);
        homeLanguageComboBox.setBounds(250, 200, 150, 25);
        
        //email address components
        emailAddressLabel = new JLabel("Email Address: ");
        emailAddressLabel.setBounds(155, 230, 200, 20);
        
        emailAddressField = new JTextField();
        emailAddressField.setBounds(250, 230, 150, 25);
        
        //password components
        passwordLabel = new JLabel("Password: ");
        passwordLabel.setBounds(179, 260, 200, 20);
        
        passwordField = new JTextField();
        passwordField.setBounds(250, 260, 150, 25);
        
       //cellphone components
        cellphoneNumberLabel = new JLabel("CellPhone Number: ");
        cellphoneNumberLabel.setBounds(134, 290, 200, 20);
        
        cellphoneNumberField =  new JTextField();
        cellphoneNumberField.setBounds(250, 290, 150, 25);
        
        //where did you hear about us components
        whereDidYouHearAboutUsLabel = new JLabel("Where did you hear about us? ");
        whereDidYouHearAboutUsLabel.setBounds(75, 320, 300, 20);
        
        String aboutUs[] = {"Choose:", "Relative", "Social Media", "Internet", "Billboards", "Newspaper", "Career Expo", "Others"};
        whereDidYouHearAboutUsComboBox = new JComboBox(aboutUs);
        whereDidYouHearAboutUsComboBox.setBounds(250, 320, 150, 25);
        
        label8 = new JLabel("STUDENT REGISTRATION");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
                
        signUpStudentButton = new JButton("SIGN-UP");
        signUpStudentButton.setBounds(1,440, 243,20);
        signUpStudentButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                    //saving student to the database implementation
                    //------------------------------------------------------------------
                    //getting selecteded items and text from field that make up a student
                    String title = (String) titleComboBox.getSelectedItem();
                    String studentId = studentIdField.getText();
                    String firstName = firstNameField.getText();
                    String lastName = lastNameField.getText();
                    String gender = (String) genderComboBox.getSelectedItem();
                    String homeLanguage = (String) homeLanguageComboBox.getSelectedItem();
                    String emailAddress = emailAddressField.getText();
                    String password = passwordField.getText();
                    String cellphoneNumber = cellphoneNumberField.getText();
                    String aboutUs = (String) whereDidYouHearAboutUsComboBox.getSelectedItem();
                    // Checking if any of the fields are empty
                    if (title.equals("Choose:") || studentId.isEmpty() || firstName.isEmpty() || lastName.isEmpty()
                        || gender.equals("Choose:") || homeLanguage.equals("Choose:") || emailAddress.isEmpty() || password.isEmpty()) {
                        // Displaying an error message to the admin indicating that all required fields must be filled
                        JOptionPane.showMessageDialog(studentSignUpFrame, "All required fields must be filled.");
                   } else {
                    Student student = new Student (title, studentId, firstName, lastName, gender, homeLanguage, emailAddress, password, cellphoneNumber, aboutUs);
                try { 
                    //Sends request to register student to the server
                    out.writeObject("RegisterStudent");
                    out.writeObject(student);
                    
                    //Recieve response from server
                    Student savedStudent = (Student) in.readObject();
                    if (savedStudent != null) {
                        // Registration was successful, do something (show a message to the user)
                        System.out.println("STUDENT REGISTERED SUCCESSFULLY");
                        JOptionPane.showMessageDialog(studentSignUpFrame, "Student " + firstNameField.getText() + " registered successfully");
                        
                        //Clearing all fields after student has be successfully registered
                        titleComboBox.setSelectedItem("Choose:");
                        studentIdField.setText("");
                        firstNameField.setText("");
                        lastNameField.setText("");
                        genderComboBox.setSelectedItem("Choose:");
                        homeLanguageComboBox.setSelectedItem("Choose:");
                        emailAddressField.setText("");
                        passwordField.setText("");
                        cellphoneNumberField.setText("");
                        whereDidYouHearAboutUsComboBox.setSelectedItem("");
                        titleComboBox.requestFocus();
                    } else {
                        // Registration failed, handle it (show an error message)
                        System.out.println("STUDENT WAS NOT REGISTERED");
                        JOptionPane.showMessageDialog(studentSignUpFrame, "Student " + firstNameField.getText() + " was not registered");
                       }
                    } catch (IOException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                  }
               }
            }
        });
        
        exitButton = new JButton("EXIT");
        exitButton.setBounds(245,440, 243,20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
            
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                studentSignUpFrame.dispose();
                adminOptionsGUI();
            }
        });
        
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(0,0,500,45);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);
        
        studentSignUpFrame.add(titleLabel);
        studentSignUpFrame.add(studentIdLabel);
        studentSignUpFrame.add(firstNameLabel);
        studentSignUpFrame.add(lastNameLabel);
        studentSignUpFrame.add(genderLabel);
        studentSignUpFrame.add(homeLanguageLabel);
        studentSignUpFrame.add(emailAddressLabel);
        studentSignUpFrame.add(passwordLabel);
        studentSignUpFrame.add(cellphoneNumberLabel);
        studentSignUpFrame.add(whereDidYouHearAboutUsLabel);
        studentSignUpFrame.add(titleComboBox);
        studentSignUpFrame.add(genderComboBox);
        studentSignUpFrame.add(homeLanguageComboBox);
        studentSignUpFrame.add(whereDidYouHearAboutUsComboBox);
        studentSignUpFrame.add(studentIdField);
        studentSignUpFrame.add(firstNameField);
        studentSignUpFrame.add(lastNameField);
        studentSignUpFrame.add(emailAddressField);
        studentSignUpFrame.add(passwordField);
        studentSignUpFrame.add(cellphoneNumberField);
        studentSignUpFrame.add(signUpStudentButton);
        studentSignUpFrame.add(exitButton);
        studentSignUpFrame.add(returnButton);
        studentSignUpFrame.add(panel2);
        studentSignUpFrame.add(panel1, BorderLayout.CENTER);
        
        studentSignUpFrame.setTitle("Student Sign Up Page");
        studentSignUpFrame.setSize(500, 500);
        studentSignUpFrame.setVisible(true);
        studentSignUpFrame.setResizable(false);
        studentSignUpFrame.setLocationRelativeTo(null);
        studentSignUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }
    
    private void retrieveStudentsGui(){
        
        JFrame retrieveStudentsFrame;
        JPanel panel1, panel2;
        JLabel label8;
        JButton searchButton, retrieveButton, deleteStudentButton, exitButton, returnButton;
        DefaultTableModel tableModel;
        JTable table;
        JScrollPane tableContainer;
        
        retrieveStudentsFrame = new JFrame();


        label8 = new JLabel("Students Registered");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
        
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        tableContainer = new JScrollPane(table);
        tableContainer.setBounds(1, 90, 985, 300);
        tableModel.addColumn("Title");
        tableModel.addColumn("StudentID");
        tableModel.addColumn("FirstName");
        tableModel.addColumn("LastName");
        tableModel.addColumn("Gender");
        tableModel.addColumn("HomeLangugae");
        tableModel.addColumn("EmailAddress");
        tableModel.addColumn("Password");
        tableModel.addColumn("CellphoneNumber");
        tableModel.addColumn("AboutUs");
        
        searchButton = new JButton("search: ");
        searchButton.setBounds(375, 55, 200, 20);
        searchButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //search for student with student id || first name || last name
                String searchTerm = JOptionPane.showInputDialog(retrieveStudentsFrame, "Enter Student ID OR First Name OR Last Name:");
                if(searchTerm != null && !searchTerm.isEmpty()){
                    try {
                        out.writeObject("findStudent");
                        out.writeObject(searchTerm);
                        out.flush();
                        
                        Object response = in.readObject();
                        if(response instanceof List<?>){
                            List<Student> studentList = (List<Student>) response;
                            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                            tableModel.setRowCount(0);
                            if(studentList.isEmpty()){
                                JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student(s) not found.");
                            } else {
                                for(Student student : studentList){
                                    Object [] rowData = {student.getTitle(), student.getStudentId(), student.getFirstName(), student.getLastName(), student.getGender(), student.getHomeLanguage(),
                                                         student.getEmailAddress(), student.getPassword(), student.getCellphoneNumber(), student.getAboutUs()};
                                    tableModel.addRow(rowData);
                                    JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student(s) found and displayed in the table.");
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student(s) not found.");
                        }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        retrieveButton = new JButton("Retrieve Students");
        retrieveButton.setBounds(350, 400, 300, 20);
        retrieveButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                //sending retrieval request to the server
                out.writeObject("Students");
                out.flush();
                //receives response from the server
                Object response = in.readObject();
                if (response instanceof List<?>) {
                    List<Student> studentList = (List<Student>) response;
                    DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                    tableModel.setRowCount(0);
                    
                    for (Student student : studentList) {
                        Object[] rowData = {student.getTitle(), student.getStudentId(), student.getFirstName(), student.getLastName(), student.getGender(),
                                  student.getHomeLanguage(), student.getEmailAddress(), student.getPassword(), student.getCellphoneNumber(), student.getAboutUs()};
                        tableModel.addRow(rowData);
                        }
                        JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student retrieval was successful");
                    } else if (response instanceof String) {
                        String message = (String) response;
                        JOptionPane.showMessageDialog(retrieveStudentsFrame, "Received a message: " + message);
                    }
                } catch (IOException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        deleteStudentButton = new JButton("Deregister");
        deleteStudentButton.setBounds(10, 440, 486, 20);
        deleteStudentButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //delete course function
                int selectedRow = table.getSelectedRow();
                if(selectedRow >= 0){
                    int confirm = JOptionPane.showConfirmDialog( retrieveStudentsFrame, "Are you sure you want to deregister this student?", "Confirmation", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String studentId = (String) tableModel.getValueAt(selectedRow, 1);
                        try {
                            // Send request to delete student from the database
                            out.writeObject("DeregisterStudent");
                            out.flush();
                            // Send request to delete student ID
                            out.writeObject(studentId);
                            out.flush();
                            Object response = in.readObject();
                            if (response instanceof String) {
                                // Client receives a response from the server
                                String result = (String) response;
                                    if (result.equals("StudentDeregistered")) {
                                       // Student deleted
                                       tableModel.removeRow(selectedRow);
                                       JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student deregistered successfully.");
                                   } else {
                                        // Student not deleted
                                        JOptionPane.showMessageDialog(retrieveStudentsFrame, "Student was not deregistered");
                                       }
                                    }
                                } catch (IOException | ClassNotFoundException ex) {
                                    ex.printStackTrace();
                            }
                       }
                    } else {
                        JOptionPane.showMessageDialog(retrieveStudentsFrame, "Please select a student to deregister.");
                }
            }
        });
                
        exitButton =  new JButton ("Exit");
        exitButton.setBounds(486, 440, 488, 20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
 
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                retrieveStudentsFrame.dispose();
                adminOptionsGUI();
            }
        });
        
                    
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,1000,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);

        
        retrieveStudentsFrame.add(tableContainer);
        retrieveStudentsFrame.add(retrieveButton);
        retrieveStudentsFrame.add(deleteStudentButton);
        retrieveStudentsFrame.add(searchButton);
        retrieveStudentsFrame.add(exitButton);
        retrieveStudentsFrame.add(returnButton);
        retrieveStudentsFrame.add(panel2);
        retrieveStudentsFrame.add(panel1, BorderLayout.CENTER);
        
        
        retrieveStudentsFrame.setTitle("Students Registered");
        retrieveStudentsFrame.setSize(1000, 500);
        retrieveStudentsFrame.setResizable(false);
        retrieveStudentsFrame.setVisible(true);
        retrieveStudentsFrame.setLocationRelativeTo(null);
        retrieveStudentsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
    
    private void adminOptionsGUI(){
        
        JFrame adminOptionsFrame;
        JPanel panel1, panel2;
        JLabel label8;
        JComboBox adminOptionsComboBox;
        JButton exitButton, returnButton;
        
        
        adminOptionsFrame = new JFrame();

        
        label8 = new JLabel("ADMINISTRATION");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        

 
        String adminOptions[]={"What Do You Want To Do?", "Add Subjects", "Add Student", "Retrieve Subjects", "Retrieve Students", "Retrieve Enrollments"};        
        adminOptionsComboBox=new JComboBox(adminOptions);    
        adminOptionsComboBox.setBounds(160,200, 200,20); 
        
        adminOptionsComboBox.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               String selectedOption = (String)adminOptionsComboBox.getSelectedItem();
               
               if("What Do You Want To Do?".equals(selectedOption)){
                   JOptionPane.showMessageDialog(adminOptionsFrame, "Please select an option or exit the Application");
               }
               else if("Add Subjects".equals(selectedOption)){
                   adminOptionsFrame.dispose();
                   addSubjectGUI();
               }
               else if("Add Student".equals(selectedOption)){
                   adminOptionsFrame.dispose();
                   studentSIGNUP();
               }
               else if("Retrieve Subjects".equals(selectedOption)){
                   adminOptionsFrame.dispose();
                   retriveSubjectsForAdminGui();
               }
               else if("Retrieve Students".equals(selectedOption)){
                   adminOptionsFrame.dispose();
                   retrieveStudentsGui();
               }
               else if("Retrieve Enrollments".equals(selectedOption)){
                   adminOptionsFrame.dispose();
                   retrieveEnrollments();
               }
               else if("Remove OR Delete Student".equals(selectedOption)){
                   
               }
            }
        });
             
        exitButton = new JButton("EXIT");
        exitButton.setBounds(0,440,487,20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                adminOptionsFrame.dispose();
                createGUI();
            }
        });
                            
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,500,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);

        
        adminOptionsFrame.add(adminOptionsComboBox);
        adminOptionsFrame.add(exitButton);
        adminOptionsFrame.add(returnButton);
        adminOptionsFrame.add(panel2);
        adminOptionsFrame.add(panel1, BorderLayout.CENTER);
        
        
        adminOptionsFrame.setTitle("ADMINISTRATION");
        adminOptionsFrame.setSize(500, 500);
        adminOptionsFrame.setResizable(false);
        adminOptionsFrame.setVisible(true);
        adminOptionsFrame.setLocationRelativeTo(null);
        adminOptionsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
    //gui for adding a course
    private void addSubjectGUI(){
        JFrame addSubjectFrame;
        JPanel panel1, panel2;
        JLabel subjectIdLabel, subjectCodeLabel, subjectNameLabel, facultyLabel, descriptionLabel, label1;
        JComboBox facultyComboBox;
        JTextField subjectIdField, subjectCodeField, subjectNameField, descriptionField;
        JButton addButton, exitButton, returnButton;        
        
        addSubjectFrame = new JFrame();

        subjectIdLabel = new JLabel("SubjectID: "); 
        subjectIdLabel.setBounds(167, 60, 100, 30); 
        subjectIdField = new JTextField();
        subjectIdField.setBounds(260, 55, 170, 40);
        
        subjectCodeLabel = new JLabel("Subject Code: "); 
        subjectCodeLabel.setBounds(167, 110, 100, 30);
        subjectCodeField = new JTextField();
        subjectCodeField.setBounds(260, 105, 170, 40);
        
        subjectNameLabel = new JLabel("Subject Name: "); 
        subjectNameLabel.setBounds(167,160, 100, 30);
        subjectNameField = new JTextField();
        subjectNameField.setBounds(260, 155, 170, 40);
        
        facultyLabel =  new JLabel("Faculty: ");
        facultyLabel.setBounds(167, 210, 100, 30);
        String faculty[]={"Choose:", "Accounting Stream", "Science Stream", "Art/Humanities Stream"};        
        facultyComboBox=new JComboBox(faculty);    
        facultyComboBox.setBounds(260, 199, 170, 40);
        
        descriptionLabel = new JLabel("Description: "); 
        descriptionLabel.setBounds(167, 260, 300, 30);
        descriptionField = new JTextField();
        descriptionField.setBounds(260, 255, 170, 40);
        
        
        label1 = new JLabel("ADD SUBJECT");
        label1.setForeground(Color.DARK_GRAY);
        label1.setFont(new Font("Serif", Font.BOLD, 20));
        
        
        addButton = new JButton("ADD SUBJECT");
        addButton.setBounds(0,440, 243,20);
        addButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //add subject Fuction
                String subjectId = subjectIdField.getText();
                String subjectCode = subjectCodeField.getText();
                String subjectName = subjectNameField.getText();
                String faculty = (String) facultyComboBox.getSelectedItem();
                String description = descriptionField.getText();
                
                 // Checking if any of the fields are empty
                if (subjectId.isEmpty() || subjectCode.isEmpty() || subjectName.isEmpty() || faculty.equals("Choose:") || description.isEmpty()) {
                   // Displaying an error message to the admin indicating that all required fields must be filled
                        JOptionPane.showMessageDialog(addSubjectFrame, "All required fields must be filled.");
                } else {
                        Course course = new Course(subjectId, subjectCode, subjectName, faculty, description);
                    try {
                        //send request to add course to server
                        out.writeObject("AddCourse");
                        out.writeObject(course);
                        
                       //response from the server
                       Course savedCourse = (Course) in.readObject();
                       if (savedCourse != null) {
                        // Registration was successful, do something (show a message to the user)
                        System.out.println("SUBJECT REGISTERED SUCCESSFULLY");
                        JOptionPane.showMessageDialog(addSubjectFrame, "Subject " + subjectNameField.getText() + " registered successfully");
                        //Clearing all fields after student has be successfully registered
                        subjectIdField.setText("");
                        subjectCodeField.setText("");
                        subjectNameField.setText("");
                        facultyComboBox.setSelectedItem("Choose:");
                        subjectIdField.requestFocus();
                        
                    } else {
                        // Registration failed, handle it (show an error message)
                        System.out.println("SUBJECT WAS NOT REGISTERED");
                        JOptionPane.showMessageDialog(addSubjectFrame, "Subject " + subjectNameField.getText() + " was not registered");
                       }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        exitButton = new JButton("Exit");
        exitButton.setBounds(243,440, 245,20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                   closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                addSubjectFrame.dispose();
                adminOptionsGUI();
            }
        });
                    
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,500,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label1);

    
        addSubjectFrame.add(subjectIdLabel);
        addSubjectFrame.add(subjectCodeLabel);
        addSubjectFrame.add(subjectNameLabel);
        addSubjectFrame.add(facultyLabel);
        addSubjectFrame.add(descriptionLabel);
        addSubjectFrame.add(facultyComboBox);
        addSubjectFrame.add(subjectIdField);
        addSubjectFrame.add(subjectCodeField);
        addSubjectFrame.add(subjectNameField);
        addSubjectFrame.add(descriptionField);
        addSubjectFrame.add(addButton);
        addSubjectFrame.add(exitButton);
        addSubjectFrame.add(returnButton);
        addSubjectFrame.add(panel2);
        addSubjectFrame.add(panel1, BorderLayout.CENTER);
        
        
        addSubjectFrame.setTitle("MARATHON EVENT REGISTRATION");
        addSubjectFrame.setSize(500, 500);
        addSubjectFrame.setResizable(false);
        addSubjectFrame.setVisible(true);
        addSubjectFrame.setLocationRelativeTo(null);
        addSubjectFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
        private void retriveSubjectsForAdminGui(){
        
        JFrame retrieveSubjectsForAdminFrame;
        JPanel panel1, panel2;
        JLabel label8, searchLabel;
        JComboBox searchCombobox;
        JButton retrieveButton, deleteCourseButton, exitButton, returnButton;
        DefaultTableModel tableModel;
        JTable table;
        JScrollPane tableContainer;
        
        retrieveSubjectsForAdminFrame = new JFrame();

        label8 = new JLabel("AVAILABALE SUBJECTS");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
        searchLabel = new JLabel("search: ");
        searchLabel.setBounds(233, 55, 100, 20);
        
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        tableContainer = new JScrollPane(table);
        tableContainer.setBounds(0, 90, 785, 300);
        tableModel.addColumn("SubjectID");
        tableModel.addColumn("SubjectCode");
        tableModel.addColumn("SubjectName");
        tableModel.addColumn("Faculty");
        tableModel.addColumn("Description");
        
        
        retrieveButton = new JButton("Retrieve Subjects");
        retrieveButton.setBounds(320, 400, 150, 20);
        retrieveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    //retrieve courses function
                    out.writeObject("Subjects");
                    out.flush();
                    
                    Object response = in.readObject();
                    if(response instanceof List<?>){
                        List<Course> courseList = (List<Course>) response;
                        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                        tableModel.setRowCount(0);
                        
                        for(Course course : courseList){
                            Object [] rowData = {course.getSubjectId(), course.getSubjectCode(), course.getSubjectName(), course.getFaculty(), course.getDescription()};
                            tableModel.addRow(rowData);
                        }
                        JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Course retrieval was successful");
                    } else if(response instanceof String){
                        String message = (String)response;
                        JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Received a message: " + message);
                    }
                } catch (IOException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        String subjectStreams[] = {"All:", "Accounting Stream", "Science Stream", "Art/Humanities Stream"};
        searchCombobox = new JComboBox(subjectStreams);
        searchCombobox.setBounds(280, 55, 200, 20);
        searchCombobox.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFaculty = (String) searchCombobox.getSelectedItem(); 
                if(selectedFaculty != null){
                    try {
                        //send request to retrieve subjects by faculty on the combobox
                        out.writeObject("RetrieveSubjectsByFaculty");
                        out.writeObject(selectedFaculty);
                        out.flush();
                        
                        //response from the server and updating the table data
                        Object response = in.readObject();
                        if(response instanceof List<?>){
                            List<Course> courseList = (List<Course>) response;
                            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                            tableModel.setRowCount(0);
                            for(Course course : courseList){
                                Object [] rowData = {course.getSubjectId(), course.getSubjectCode(), course.getSubjectName(), course.getFaculty(), course.getDescription()};
                                tableModel.addRow(rowData);
                            }
                            JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Subjects retrieval was successful");
                        } else if(response instanceof String) {
                            String message = (String) response;
                            JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Received a message: " + message);
                        }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        deleteCourseButton = new JButton("Delete Subject");
        deleteCourseButton.setBounds(10, 440, 385, 20);
        deleteCourseButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //delete course function
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    int confirm = JOptionPane.showConfirmDialog(retrieveSubjectsForAdminFrame, "Are you sure you want to delete this subject?", "Confirmation", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String subjectId = (String) tableModel.getValueAt(selectedRow, 0);
                        try {
                            // Send request to delete subject from the database
                            out.writeObject("DeleteSubject");
                            out.flush();
                            // Send request to delete subject
                            out.writeObject(subjectId);
                            out.flush();
                            Object response = in.readObject();
                            if (response instanceof String) {
                                // Client receives a response from the server
                                String result = (String) response;
                                    if (result.equals("CourseDeleted")) {
                                       // Subject deleted
                                       tableModel.removeRow(selectedRow);
                                       JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Subject deleted successfully.");
                                   } else {
                                        // Subject not deleted
                                        JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Subject was not deleted");
                                       }
                                    }
                                } catch (IOException | ClassNotFoundException ex) {
                                    ex.printStackTrace();
                            }
                       }
                    } else {
                        JOptionPane.showMessageDialog(retrieveSubjectsForAdminFrame, "Please select a subject to delete.");
                }
            }
        });
        
        exitButton =  new JButton ("Exit");
        exitButton.setBounds(385, 440, 388, 20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                   closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                retrieveSubjectsForAdminFrame.dispose();
                adminOptionsGUI();
            }
        });
 
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,800,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);
        
        retrieveSubjectsForAdminFrame.add(searchLabel);
        retrieveSubjectsForAdminFrame.add(searchCombobox);
        retrieveSubjectsForAdminFrame.add(tableContainer);
        retrieveSubjectsForAdminFrame.add(retrieveButton);
        retrieveSubjectsForAdminFrame.add(deleteCourseButton);
        retrieveSubjectsForAdminFrame.add(exitButton);
        retrieveSubjectsForAdminFrame.add(returnButton);
        retrieveSubjectsForAdminFrame.add(panel2);
        retrieveSubjectsForAdminFrame.add(panel1, BorderLayout.CENTER);
        
        retrieveSubjectsForAdminFrame.setTitle("AVAILABLE SUBJECTS");
        retrieveSubjectsForAdminFrame.setSize(800, 500);
        retrieveSubjectsForAdminFrame.setResizable(false);
        retrieveSubjectsForAdminFrame.setVisible(true);
        retrieveSubjectsForAdminFrame.setLocationRelativeTo(null);
        retrieveSubjectsForAdminFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
    
    private void retrieveSubjectsForStudentGui(){
        
        JFrame retrieveSubjectsForStudentFrame;
        JPanel panel1, panel2;
        JLabel label8, searchLabel;
        JComboBox searchCombobox;
        JButton retrieveButton, exitButton,returnButton, enrollButton;
        DefaultTableModel tableModel;
        JTable table;
        JScrollPane tableContainer;
        
        retrieveSubjectsForStudentFrame = new JFrame();

        label8 = new JLabel("Available Subjects to Enroll In");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
        searchLabel = new JLabel("search: ");
        searchLabel.setBounds(233, 55, 100, 20);
        
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        tableContainer = new JScrollPane(table);
        tableContainer.setBounds(0, 90, 785, 300);
        tableModel.addColumn("SubjectID");
        tableModel.addColumn("SubjectCode");
        tableModel.addColumn("SubjectName");
        tableModel.addColumn("Faculty");
        tableModel.addColumn("Description");
        
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                retrieveSubjectsForStudentFrame.dispose();
                createGUI();
            }
        });
        
        retrieveButton = new JButton("Retrieve Subjects");
        retrieveButton.setBounds(320, 400, 150, 20);
        retrieveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //retrieve courses function
                try{
                    out.writeObject("Subjects");
                    out.flush();
                    
                    Object response = in.readObject();
                    if(response instanceof List<?>){
                        List<Course> courseList = (List<Course>) response;
                        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                        tableModel.setRowCount(0);
                        
                        for(Course course : courseList){
                            Object [] rowData = {course.getSubjectId(), course.getSubjectCode(), course.getSubjectName(), course.getFaculty(), course.getDescription()};
                            tableModel.addRow(rowData);
                        }
                        JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Course retrieval was successful");
                    } else if (response instanceof String){
                        String message = (String)response;
                        JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Received a message: " + message);
                    }
                 } catch (IOException | ClassNotFoundException ex) {
                     ex.printStackTrace();
               }
            }
        });
        
        String subjectStreams[] = {"All:", "Accounting Stream", "Science Stream", "Art/Humanities Stream"};
        searchCombobox = new JComboBox(subjectStreams);
        searchCombobox.setBounds(280, 55, 200, 20);
        searchCombobox.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFaculty = (String) searchCombobox.getSelectedItem(); 
                if(selectedFaculty != null){
                    try {
                        //send request to retrieve subjects by faculty on the combobox
                        out.writeObject("RetrieveSubjectsByFaculty");
                        out.writeObject(selectedFaculty);
                        out.flush();
                        
                        //response from the server and updating the table data
                        Object response = in.readObject();
                        if(response instanceof List<?>){
                            List<Course> courseList = (List<Course>) response;
                            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                            tableModel.setRowCount(0);
                            for(Course course : courseList){
                                Object [] rowData = {course.getSubjectId(), course.getSubjectCode(), course.getSubjectName(), course.getFaculty(), course.getDescription()};
                                tableModel.addRow(rowData);
                            }
                            JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Subjects retrieval was successful");
                        } else if(response instanceof String) {
                            String message = (String) response;
                            JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Received a message: " + message);
                        }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        enrollButton = new JButton("Enroll");
        enrollButton.setBounds(10, 440, 385, 20);
        enrollButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //enroll function
                int selectedRow = table.getSelectedRow();
                if(selectedRow != -1){
                    String studentId = JOptionPane.showInputDialog(retrieveSubjectsForStudentFrame, "Enter your Student ID:");
                    if (studentId != null && !studentId.isEmpty()){
                        try {
                            String subjectId = (String) tableModel.getValueAt(selectedRow, 0);
                            out.writeObject("Enroll");
                            out.writeObject(studentId);
                            out.writeObject(subjectId);
                            
                            Object response = in.readObject();
                            if(response instanceof String){
                                String message = (String) response;
                                if ("Enrollment successful".equalsIgnoreCase(message)){
                                    JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "You have successfully enrolled in " + tableModel.getValueAt(selectedRow, 2));
                                } else {
                                    JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Enrollment unsuccessful. Student is already enrolled in subject OR student is not registered");
                                }
                            }
                        } catch (IOException | ClassNotFoundException ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Enrollment cancelled");
                    }
                } else {
                    JOptionPane.showMessageDialog(retrieveSubjectsForStudentFrame, "Please select a subject to enroll in.");
                }
            }
        });
        
        exitButton =  new JButton ("Exit");
        exitButton.setBounds(385, 440, 388, 20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
 
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,800,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);
        
        retrieveSubjectsForStudentFrame.add(searchLabel);
        retrieveSubjectsForStudentFrame.add(searchCombobox);
        retrieveSubjectsForStudentFrame.add(tableContainer);
        retrieveSubjectsForStudentFrame.add(retrieveButton);
        retrieveSubjectsForStudentFrame.add(exitButton);
        retrieveSubjectsForStudentFrame.add(returnButton);
        retrieveSubjectsForStudentFrame.add(enrollButton);
        retrieveSubjectsForStudentFrame.add(panel2);
        retrieveSubjectsForStudentFrame.add(panel1, BorderLayout.CENTER);
        
        retrieveSubjectsForStudentFrame.setTitle("Students Registered");
        retrieveSubjectsForStudentFrame.setSize(800, 500);
        retrieveSubjectsForStudentFrame.setResizable(false);
        retrieveSubjectsForStudentFrame.setVisible(true);
        retrieveSubjectsForStudentFrame.setLocationRelativeTo(null);
        retrieveSubjectsForStudentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}    
        
    private void retrieveEnrollments(){
        
        JFrame retrieveEnrollmentsFrame;
        JPanel panel1, panel2;
        JLabel label8;
        JButton returnButton, searchButton, retrieveButton, cancelButton, exitButton;
        DefaultTableModel tableModel;
        JTable table;
        JScrollPane tableContainer;
        
        retrieveEnrollmentsFrame = new JFrame();

        label8 = new JLabel("Enrollments");
        label8.setForeground(Color.DARK_GRAY);
        label8.setFont(new Font("Serif", Font.BOLD, 20));
        
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        tableContainer = new JScrollPane(table);
        tableContainer.setBounds(0, 110, 500, 270);
        tableModel.addColumn("EnrollmentID");
        tableModel.addColumn("CourseID");
        tableModel.addColumn("StudentID");  
        
        searchButton = new JButton("search: ");
        searchButton.setBounds(200, 70, 100, 20);
        searchButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //search for enrollments using subject id and student id
                String searchTerm = JOptionPane.showInputDialog(retrieveEnrollmentsFrame, "Enter Student ID OR Subject ID:");
                if(searchTerm != null && !searchTerm.isEmpty()){
                    try {
                        out.writeObject("findSpecificEnrollments");
                        out.writeObject(searchTerm);
                        out.flush();
                        
                        Object response = in.readObject();
                        if (response instanceof List<?>) {
                            List<Enrollment> enrollList = (List<Enrollment>) response;
                            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                            tableModel.setRowCount(0);
                            if (enrollList.isEmpty()) {
                                JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Data search for : " + searchTerm + " was not found");
                            } else {
                                for (Enrollment enrollment : enrollList) {
                                    Object[] rowData = {enrollment.getEnrollmentId(), enrollment.getSubjectId(), enrollment.getStudentId()};
                                    tableModel.addRow(rowData);
                                }
                                JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Data found and displayed in the table.");
                            }
                        } else if (response instanceof String) {
                            JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Data not found.");
                        }
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
                
        retrieveButton = new JButton("Enrollments");
        retrieveButton.setBounds(170,400, 150,20);
        retrieveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    //retrieve courses function
                    out.writeObject("Enrollments");
                    out.flush();
                    
                    Object response = in.readObject();
                    if(response instanceof List<?>){
                        List<Enrollment> enrolledList = (List<Enrollment>) response;
                        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
                        tableModel.setRowCount(0);
                        
                        for(Enrollment enrollment : enrolledList){
                            Object [] rowData = {enrollment.getEnrollmentId(), enrollment.getSubjectId(), enrollment.getStudentId()};
                            tableModel.addRow(rowData);
                        }
                        JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Enrollments retrieval was successful");
                    } else if (response instanceof String){
                        String message = (String) response;
                        JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Received a message: " + message);
                    }
                } catch (IOException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        cancelButton = new JButton("Cancel Enrollment");
        cancelButton.setBounds(1, 440, 240, 20);
        cancelButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //cancel student enrollment function
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    int confirm = JOptionPane.showConfirmDialog(retrieveEnrollmentsFrame, "Are you sure you want to cancel this enrollment?", "Confirmation", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        String subjectId = (String) tableModel.getValueAt(selectedRow, 1);
                        try {
                            // Send request to cancel enrollement from the database
                            out.writeObject("CancelEnrollment");
                            out.flush();
                            // Send request to cancel enrollment
                            out.writeObject(subjectId);
                            out.flush();
                            Object response = in.readObject();
                            if (response instanceof String) {
                                // Client receives a response from the server
                                String result = (String) response;
                                    if (result.equals("EnrollmentCancelled")) {
                                       // Enrollment cancelled
                                       tableModel.removeRow(selectedRow);
                                       JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Enrollment cancelled successfully.");
                                   } else {
                                        // Enrollment not cancelled
                                        JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Enrollment was not cancelled");
                                       }
                                    }
                                } catch (IOException | ClassNotFoundException ex) {
                                    ex.printStackTrace();
                            }
                       }
                    } else {
                        JOptionPane.showMessageDialog(retrieveEnrollmentsFrame, "Please select an enrollment to cancel.");
                }
            }
        });
        
        exitButton =  new JButton ("Exit");
        exitButton.setBounds(245, 440, 240, 20);
        exitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    closeConnection();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        returnButton = new JButton("RETURN");
        returnButton.setBounds(0, 51, 100, 20);
        returnButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                retrieveEnrollmentsFrame.dispose();
                adminOptionsGUI();
            }
        });
 
        panel1 = new JPanel();
        panel1.setBackground(Color.pink);
        
        panel2 = new JPanel();
        panel2.setBounds(1,1,500,50);
        panel2.setBackground(Color.LIGHT_GRAY);
        panel2.add(label8);

        retrieveEnrollmentsFrame.add(tableContainer);
        retrieveEnrollmentsFrame.add(searchButton);
        retrieveEnrollmentsFrame.add(retrieveButton);
        retrieveEnrollmentsFrame.add(cancelButton);
        retrieveEnrollmentsFrame.add(exitButton);
        retrieveEnrollmentsFrame.add(returnButton);
        retrieveEnrollmentsFrame.add(panel2);
        retrieveEnrollmentsFrame.add(panel1, BorderLayout.CENTER);
        
        retrieveEnrollmentsFrame.setTitle("Students Registered");
        retrieveEnrollmentsFrame.setSize(500, 500);
        retrieveEnrollmentsFrame.setResizable(false);
        retrieveEnrollmentsFrame.setVisible(true);
        retrieveEnrollmentsFrame.setLocationRelativeTo(null);
        retrieveEnrollmentsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
}
    
    private void closeConnection() throws IOException{
        
        out.writeObject("Exit");
        out.close();
        out.flush();
        in.close();
        socket.close();
        System.out.println("\nClient is closing all connections: ");
        System.exit(0);
    
    }
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        EnrollmentClient client = new EnrollmentClient();
        client.createGUI();
    }
}