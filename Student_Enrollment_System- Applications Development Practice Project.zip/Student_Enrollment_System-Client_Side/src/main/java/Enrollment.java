
import java.io.Serializable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Enrollment implements Serializable{
    
    private int enrollmentId;
    private String subjectId;
    private String studentId;

    public Enrollment() {
    }

    public Enrollment(int enrollmentId, String subjectId, String studentId) {
        this.enrollmentId = enrollmentId;
        this.subjectId = subjectId;
        this.studentId = studentId;
    }

    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return "Enrollment{" + "enrollmentId=" + enrollmentId + ", subjectId=" + subjectId + ", studentId=" + studentId + '}';
    }
}
